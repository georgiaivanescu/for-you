import numpy as np
import pandas as pd

#ex1

array_1 = np.genfromtxt('./dataIN/matrix_2.txt', delimiter=',')
print(array_1)


#ex 2
array_2 = np.full((7, 7), 9)
print(array_2)
array_2.fill(5)
array_2[1:-1, 1:-1] = 0
print(array_2)

#ex3

array_3 = np.random.uniform(low=0, high=10, size=100)
df_3 = pd.DataFrame(array_3, index=[f"L_{i + 1}" for i in range(100)])
print(df_3)

#ex4

array_4 = np.random.uniform(low=0, high=10, size=(11, 5))
df_4 = pd.DataFrame(array_4, index=[f"L{i + 1}" for i in range(11)], columns=[f"C{i + 1}" for i in range(5)])
print(df_4)


#ex5
array_5 = {f"S_{i + 1}": np.random.randint(low=1, high=11, size=7) for i in range(7)}
print(array_5)


#ex 6
array_6 = np.full((7, 7), 4)
array_6[1:-1, 1:-1] = 0

# sub_matrix_6 = array_6[1:-1, 1:-1] # easy solution
# print(sub_matrix_6)

# Dynamic solution
(rows, cols) = np.where(array_6 == 0)

min_row, max_row = rows.min(), rows.max()
min_col, max_col = cols.min(), cols.max()

sub_matrix_6 = np.full((max_row - min_row + 1, max_col - min_col + 1), np.nan)

for r, c in zip(rows, cols):
    sub_matrix_6[r - min_row, c - min_col] = 0

print(sub_matrix_6)

#ex7

faculty_7 = {f"An{i + 1}": {f"Stud{j + 1}": np.random.randint(low=1, high=11, size=5) for j in range(8)} for i in
             range(5)}
df_7 = pd.DataFrame(faculty_7)
print(df_7)

#ex8

series_1 = pd.read_csv("./dataIN/Series_1.csv", header=0, index_col=0).squeeze()
series_2 = pd.read_csv("./dataIN/Series_2.csv", header=0, index_col=0).squeeze()
dict_8 = {'Col1': series_1, 'Col2': series_2}
df_8 = pd.DataFrame(dict_8)
print(df_8)


#ex9
matrix_9 = np.full((7, 7), 4)
matrix_9[1:-1, 1:-1] = 0
np.fill_diagonal(matrix_9, 11)
matrix_9[3, 3] = 99
print(matrix_9)

