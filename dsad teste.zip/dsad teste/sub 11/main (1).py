import numpy as np
import pandas as pd

# Ex 1
matrix_1 = np.full((7, 7), 0)
matrix_1[0, :] = 7
matrix_1[-1, :] = 7
matrix_1[:, 0] = 7
matrix_1[:, -1] = 7
np.fill_diagonal(matrix_1, 33)
matrix_1[3, 3] = 77
print(matrix_1)

# Ex 2

matrix_2 = np.full((7, 7), np.nan)
print(matrix_2)
matrix_2[0, :] = 5
matrix_2[-1, :] = 5
matrix_2[:, 0] = 5
matrix_2[:, -1] = 5
matrix_2 = np.nan_to_num(matrix_2, nan=0)
print(matrix_2)

# Ex 3
matrix_of_0s = matrix_2[1:-1, 1:-1]

print(matrix_of_0s)

# Ex 4
rand_vector = np.random.uniform(0, 100, 100)
labels = [f"L_{i + 1}" for i in range(100)]
rand_df = pd.DataFrame(rand_vector, index=labels)
print(rand_df)

# Ex 5
rand_matrix = np.random.uniform(0, 10, (11, 5))
row_labels = [f"L{i + 1}" for i in range(11)]
col_labels = [f"C{i + 1}" for i in range(5)]
rand_matrix_df = pd.DataFrame(rand_matrix, index=row_labels, columns=col_labels)
print(rand_matrix_df)

# Ex 6
students = {f"S_{i + 1}": np.random.randint(1, 11, 7) for i in range(8)}
students_df = pd.DataFrame(students)
print(students_df)

# Ex 7
students = {f"Stud{i}": pd.Series(np.random.randint(1, 11, 5), index=[f"Ex{i + 1}" for i in range(5)]) for i in
            range(7)}
students_df = pd.DataFrame(students)
# print(students)
print(students_df)

# Ex 8

series_1 = pd.read_csv('./dataIN/Series_1.csv', header=None, skiprows=1, index_col=0).squeeze()
series_2 = pd.read_csv('./dataIN/Series_2.csv', header=None, skiprows=1, index_col=0).squeeze()
print(series_1)
data_dict = {
    'Col1': series_1,
    'Col2': series_2
}

df = pd.DataFrame(data_dict)
print(df)

# Ex 9
faculty = {f"An{i + 1}": {f"Stud{j + 1}": np.random.randint(1, 11, 5) for j in range(8)} for i in range(5)}
faculty_df = pd.DataFrame(faculty)
print(faculty_df)
